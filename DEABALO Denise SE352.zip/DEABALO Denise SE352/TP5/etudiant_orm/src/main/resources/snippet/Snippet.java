package snippet;

public class Snippet {
	Could not locate cfg.xml resource [hibernate.cfg.xml]
		at org.hibernate.boot.cfgxml.internal.ConfigLoader.loadConfigXm
}

